package br.edu.fatec.app1508;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText edtNome;
    private EditText edtEndereco;
    private EditText edtResultado;
    private Button btnMostrarDados;
    private Button btnLimpar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        //findViewById to find element in xml
        edtNome = findViewById(R.id.edtNome);
        edtEndereco = findViewById(R.id.edtEndereco);
        edtResultado = findViewById(R.id.edtResultado);
        btnLimpar = findViewById(R.id.btnLimpar);
        btnMostrarDados = findViewById(R.id.btnMostrarDados);

    }

    public void Mostrar(View view){
        edtResultado.append("Nome: " + edtNome.getText());
        edtResultado.append("\nEndereço: " + edtEndereco.getText());
    }

    public void Limpar(View view){
        edtNome.setText(null);
        edtResultado.setText(null);
        edtEndereco.setText(null);

    }
}